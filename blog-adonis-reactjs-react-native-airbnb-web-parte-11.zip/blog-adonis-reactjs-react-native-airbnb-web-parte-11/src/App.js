import React from "react";
import Routes from "./routes";
import "./styles/global";

const App = () => <Routes />;
export default App;
